import torch
import transformers
from transformers import AutoTokenizer, AutoModel
import langchain
import faiss

def main():
	print("langchain version:", langchain.__version__)

	print("transformers version:", transformers.__version__)
	model_name = "distilbert-base-uncased"
	tokenizer = AutoTokenizer.from_pretrained(model_name)
	model = AutoModel.from_pretrained(model_name)
	print("distilbert-base-uncased loaded successfully.")

	index = faiss.IndexFlatL2(128)
	print("faiss version:", faiss.__version__)

	print("PyTorch version:", torch.__version__)
	
	if torch.cuda.is_available():
		print("CUDA is available!")
	else:
		print("CUDA is not available.")


if __name__ == '__main__':
	main()